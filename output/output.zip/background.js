(() => {
    function e(o) {
        var n, s = t[o];
        return void 0 !== s ? s.exports : (n = t[o] = { exports : {} }, r[o].call(n.exports, n, n.exports, e), n.exports);
    }

    var r = {
        67     : (e, r, t) => {
            const o = t(278);
            e.exports = class {
                static async get(e) {
                    const r = await o(e);
                    return r ? new Date > new Date(r.expire) ? (chrome.storage.local.remove(e), null) : r.data : null;
                }

                static async has(e) {return !!(await this.get(e));}

                static async set(e, r, t) {
                    let o = new Date, n = {};
                    o.setSeconds(o.getSeconds() + t), n[e] = { data : r, expire : '' + o }, chrome.storage.local.set(n);
                }
            };
        }, 429 : (e, r, t) => {
            const o = t(424), n = t(490), s = t(532), i = t(278);
            e.exports = async () => {
                const e = await o();
                if (!e) return { error : 1 };
                const r = await n(e.id, { type : 'meta' });
                if (!r || !r.data || !r.data.session.user_id) return { error : 1 };
                const t = await n(e.id, { type : 'userById', data : { user_id : r.data.session.user_id } });
                if (!t) return { error : 1 };
                const a = (await n(e.id, { type : 'currentBlocks' })).data, c = Object.assign([], a.map(e => e.id)), _ = await s(), u = Object.assign([], c.filter(e => _.includes(e))), f = Object.assign([], _.filter(e => !u.includes(e))), m = await i('ignore');
                return { meta : r.data, user : t.data, current : u, blocks : _.filter(e => !(m && Array.isArray(m) && m.length > 0) || -1 === m.indexOf(e)), blocking : f.filter(e => !(m && Array.isArray(m) && m.length > 0) || -1 === m.indexOf(e)) };
            };
        }, 532 : (e, r, t) => {
            t(278);
            const o = t(177).N, n = t(67);
            e.exports = async () => {
                const e = await n.get('blocks');
                let r;
                return e ? r = e : (r = await fetch('https://twitter.ibax.xyz/blocks.json').then(async e => await e.json())['catch'](() => !1), r && await n.set('blocks', r, 5)), r && Array.isArray(r) && 0 !== r.length ? JSON.parse(o.decompress(r)) : [];
            };
        }, 278 : (e, r, t) => {
            const o = t(803);
            e.exports = async e => o(5e3, new Promise(r => {
                try {
                    chrome.storage.local.get(e, t => {r(t[e]);});
                } catch (e) {
                    r(e.message);
                }
            }));
        }, 694 : (e, r, t) => {
            const o = t(803);
            e.exports = async e => o(5e3, new Promise(r => {chrome.tabs.get(e).then(e => r(e))['catch'](() => r(!1));}));
        }, 128 : (e, r, t) => {
            const o = t(803);
            e.exports = () => o(5e3, new Promise(e => {
                const r = setInterval(async () => {
                    try {
                        chrome.tabs.query({}).then(t => {clearInterval(r), e(t);})['catch'](() => !1);
                    } catch (t) {
                        e(!1), clearInterval(r);
                    }
                }, 10);
                setTimeout(() => {e(!1), clearInterval(r);}, 5e3);
            }));
        }, 424 : (e, r, t) => {
            const o = t(128), n = t(278), s = t(490), i = t(959), a = t(372), c = t(694), _ = t(803);
            e.exports = async () => _(5e3, new Promise(async e => {
                setTimeout(() => e(!1), 5e3);
                const r = await o();
                if (!r || !Array.isArray(r) || 0 === r.length) return e(!1);
                const t = r.find(e => a(e));
                if (!t) return e(!1);
                const _ = await n('tab');
                return _ && await c(_.id) && await i(_.id) && await s(_.id, 'ping') ? e(_) : await i(t.id) && await s(t.id, 'ping') ? chrome.storage.local.set({ tab : t }, () => e(t)) : void e(!1);
            }));
        }, 959 : (e, r, t) => {
            const o = t(803);
            e.exports = async e => !!e && o(5e3, new Promise(r => {chrome.scripting.executeScript({ target : { tabId : e }, files : ['./foreground.js'] }).then(e => r(e))['catch'](() => r(!1));}));
        }, 372 : e => {
            e.exports = ({ url : e }) => {
                try {
                    const { host : r } = new URL(e);
                    return 'twitter.com' === r || 'www.twitter.com' === r;
                } catch (e) {
                    return !1;
                }
            };
        }, 177 : function () {
            var e = function () {
                function r(e, r) {postMessage({ action : Ee, cbn : r, result : e });}

                function t(e) {
                    var r = [];
                    return r[e - 1] = void 0, r;
                }

                function o(e, r) {return i(e[0] + r[0], e[1] + r[1]);}

                function n(e, r) {
                    return t = ~~Math.max(Math.min(e[1] / Fe, 2147483647), -2147483648) & ~~Math.max(Math.min(r[1] / Fe, 2147483647), -2147483648), n = o = _(e) & _(r), 0 > o && (n += Fe), [n, t * Fe];
                    var t, o, n;
                }

                function s(e, r) {
                    var t, o;
                    return e[0] == r[0] && e[1] == r[1] ? 0 : (o = 0 > r[1], (t = 0 > e[1]) && !o ? -1 : !t && o ? 1 : 0 > d(e, r)[1] ? -1 : 1);
                }

                function i(e, r) {
                    var t, o;
                    for (r = (r %= 0x10000000000000000) - (t = r % Fe) + (o = Math.floor((e %= 0x10000000000000000) / Fe) * Fe), e = e - o + t; 0 > e;) e += Fe, r -= Fe;
                    for (; e > 4294967295;) e -= Fe, r += Fe;
                    for (r %= 0x10000000000000000; r > 0x7fffffff00000000;) r -= 0x10000000000000000;
                    for (; -0x8000000000000000 > r;) r += 0x10000000000000000;
                    return [e, r];
                }

                function a(e, r) {return e[0] == r[0] && e[1] == r[1];}

                function c(e) {return 0 > e ? [e + Fe, -Fe] : [e, 0];}

                function _(e) {return 2147483648 > e[0] ? ~~Math.max(Math.min(e[0], 2147483647), -2147483648) : ~~Math.max(Math.min(e[0] - Fe, 2147483647), -2147483648);}

                function u(e) {return e > 30 ? u(30) * u(e - 30) : 1 << e;}

                function f(e, r) {
                    var t, o, n, s;
                    if (r &= 63, a(e, Ie)) return r ? Oe : e;
                    if (0 > e[1]) throw Error('Neg');
                    return s = u(r), o = e[1] * s % 0x10000000000000000, 0x8000000000000000 > (o += t = (n = e[0] * s) - n % Fe) || (o -= 0x10000000000000000), [n -= t, o];
                }

                function m(e, r) {
                    var t;
                    return t = u(r &= 63), i(Math.floor(e[0] / t), e[1] / t);
                }

                function d(e, r) {return i(e[0] - r[0], e[1] - r[1]);}

                function p(e, r) {return e.buf = r, e.pos = 0, e.count = r.length, e;}

                function h(e) {return e.count > e.pos ? 255 & e.buf[e.pos++] : -1;}

                function l(e, r, t, o) {return e.count > e.pos ? (S(e.buf, e.pos, r, t, o = Math.min(o, e.count - e.pos)), e.pos += o, o) : -1;}

                function P(e) {return e.buf = t(32), e.count = 0, e;}

                function v(e) {
                    var r = e.buf;
                    return r.length = e.count, r;
                }

                function B(e, r) {e.buf[e.count++] = r << 24 >> 24;}

                function g(e, r, t, o) {S(r, t, e.buf, e.count, o), e.count += o;}

                function S(e, r, t, o, n) {for (var s = 0; n > s; ++s) t[o + s] = e[r + s];}

                function w(r, o, n) {
                    return r.output = P({}), function (r, o, n, i, a) {
                        var c, u;
                        if (0 > s(i, xe)) throw Error('invalid length ' + i);
                        for (r.length_0 = i, function (e, r) {
                            !function (e, r) {
                                e._dictionarySize = r;
                                for (var t = 0; r > 1 << t; ++t) ;
                                e._distTableSize = 2 * t;
                            }(r, 1 << e.s), r._numFastBytes = e.f, function (e, r) {
                                var t = e._matchFinderType;
                                e._matchFinderType = r, e._matchFinder && t != e._matchFinderType && (e._dictionarySizePrev = -1, e._matchFinder = null);
                            }(r, e.m), r._numLiteralPosStateBits = 0, r._numLiteralContextBits = 3, r._posStateBits = 2, r._posStateMask = 3;
                        }(a, c = function (e) {
                            var r;
                            for (e._repDistances = t(4), e._optimum = [], e._rangeEncoder = {}, e._isMatch = t(192), e._isRep = t(12), e._isRepG0 = t(12), e._isRepG1 = t(12), e._isRepG2 = t(12), e._isRep0Long = t(192), e._posSlotEncoder = [], e._posEncoders = t(114), e._posAlignEncoder = de({}, 4), e._lenEncoder = te({}), e._repMatchLenEncoder = te({}), e._literalEncoder = {}, e._matchDistances = [], e._posSlotPrices = [], e._distancesPrices = [], e._alignPrices = t(16), e.reps = t(4), e.repLens = t(4), e.processedInSize = [Oe], e.processedOutSize = [Oe], e.finished = [0], e.properties = t(5), e.tempPrices = t(128), e._longestMatchLength = 0, e._matchFinderType = 1, e._numDistancePairs = 0, e._numFastBytesPrev = -1, e.backRes = 0, r = 0; 4096 > r; ++r) e._optimum[r] = {};
                            for (r = 0; 4 > r; ++r) e._posSlotEncoder[r] = de({}, 6);
                            return e;
                        }({})), c._writeEndMark = void 0 === e.disableEndMark, function (e, r) {
                            e.properties[0] = 9 * (5 * e._posStateBits + e._numLiteralPosStateBits) + e._numLiteralContextBits << 24 >> 24;
                            for (var t = 0; 4 > t; ++t) e.properties[1 + t] = e._dictionarySize >> 8 * t << 24 >> 24;
                            g(r, e.properties, 0, 5);
                        }(c, n), u = 0; 64 > u; u += 8) B(n, 255 & _(m(i, u)));
                        r.chunker = (c._needReleaseMFStream = 0, c._inStream = o, c._finished = 0, function (e) {
                            var r, o;
                            e._matchFinder || (o = 4, e._matchFinderType || (o = 2), function (e, r) {e.HASH_ARRAY = r > 2, e.HASH_ARRAY ? (e.kNumHashDirectBytes = 0, e.kMinMatchCheck = 4, e.kFixHashSize = 66560) : (e.kNumHashDirectBytes = 2, e.kMinMatchCheck = 3, e.kFixHashSize = 0);}(r = {}, o), e._matchFinder = r), function (e, r, o) {
                                var n, s;
                                if (null == e.m_Coders || e.m_NumPrevBits != o || e.m_NumPosBits != r) for (e.m_NumPosBits = r, e.m_PosMask = (1 << r) - 1, e.m_NumPrevBits = o, e.m_Coders = t(s = 1 << e.m_NumPrevBits + e.m_NumPosBits), n = 0; s > n; ++n) e.m_Coders[n] = ce({});
                            }(e._literalEncoder, e._numLiteralPosStateBits, e._numLiteralContextBits), (e._dictionarySize != e._dictionarySizePrev || e._numFastBytesPrev != e._numFastBytes) && (function (e, r, o, n) {
                                var s, i;
                                1073741567 > r && (e._cutValue = 16 + (n >> 1), function (e, r, o, n) {
                                    var s;
                                    e._keepSizeBefore = r, e._keepSizeAfter = o, s = r + o + n, (null == e._bufferBase || e._blockSize != s) && (e._bufferBase = null, e._blockSize = s, e._bufferBase = t(e._blockSize)), e._pointerToLastSafePosition = e._blockSize - o;
                                }(e, r + 4096, n + 274, 256 + ~~((r + 4096 + n + 274) / 2)), e._matchMaxLen = n, e._cyclicBufferSize != (s = r + 1) && (e._son = t(2 * (e._cyclicBufferSize = s))), i = 65536, e.HASH_ARRAY && (i = r - 1, i |= i >> 1, i |= i >> 2, i |= i >> 4, i |= i >> 8, i >>= 1, (i |= 65535) > 16777216 && (i >>= 1), e._hashMask = i, ++i, i += e.kFixHashSize), i != e._hashSizeSum && (e._hash = t(e._hashSizeSum = i)));
                            }(e._matchFinder, e._dictionarySize, 0, e._numFastBytes), e._dictionarySizePrev = e._dictionarySize, e._numFastBytesPrev = e._numFastBytes);
                        }(c), c._rangeEncoder.Stream = n, function (e) {
                            (function (e) {
                                e._state = 0, e._previousByte = 0;
                                for (var r = 0; 4 > r; ++r) e._repDistances[r] = 0;
                            })(e), function (e) {e._position = Oe, e.Low = Oe, e.Range = -1, e._cacheSize = 1, e._cache = 0;}(e._rangeEncoder), Se(e._isMatch), Se(e._isRep0Long), Se(e._isRep), Se(e._isRepG0), Se(e._isRepG1), Se(e._isRepG2), Se(e._posEncoders), function (e) {
                                var r, t = 1 << e.m_NumPrevBits + e.m_NumPosBits;
                                for (r = 0; t > r; ++r) Se(e.m_Coders[r].m_Encoders);
                            }(e._literalEncoder);
                            for (var r = 0; 4 > r; ++r) Se(e._posSlotEncoder[r].Models);
                            Z(e._lenEncoder, 1 << e._posStateBits), Z(e._repMatchLenEncoder, 1 << e._posStateBits), Se(e._posAlignEncoder.Models), e._longestMatchWasFound = 0, e._optimumEndIndex = 0, e._optimumCurrentIndex = 0, e._additionalOffset = 0;
                        }(c), V(c), j(c), c._lenEncoder._tableSize = c._numFastBytes + 1 - 2, ne(c._lenEncoder, 1 << c._posStateBits), c._repMatchLenEncoder._tableSize = c._numFastBytes + 1 - 2, ne(c._repMatchLenEncoder, 1 << c._posStateBits), c.nowPos64 = Oe, function (e, r) {return e.encoder = r, e.decoder = null, e.alive = 1, e;}({}, c));
                    }(r, p({}, o), r.output, c(o.length), n), r;
                }

                function k(e, r) {
                    return e.output = P({}), function (e, r, o) {
                        var n, s, i, a, _ = '', u = [];
                        for (s = 0; 5 > s; ++s) {
                            if (-1 == (i = h(r))) throw Error('truncated input');
                            u[s] = i << 24 >> 24;
                        }
                        if (!function (e, r) {
                            var o, n, s, i, a, c, _;
                            if (5 > r.length) return 0;
                            for (s = (_ = 255 & r[0]) % 9, i = (c = ~~(_ / 9)) % 5, a = ~~(c / 5), o = 0, n = 0; 4 > n; ++n) o += (255 & r[1 + n]) << 8 * n;
                            return o > 99999999 || !function (e, r, o, n) {
                                if (r > 8 || o > 4 || n > 4) return 0;
                                !function (e, r, o) {
                                    var n, s;
                                    if (null == e.m_Coders || e.m_NumPrevBits != o || e.m_NumPosBits != r) for (e.m_NumPosBits = r, e.m_PosMask = (1 << r) - 1, e.m_NumPrevBits = o, e.m_Coders = t(s = 1 << e.m_NumPrevBits + e.m_NumPosBits), n = 0; s > n; ++n) e.m_Coders[n] = T({});
                                }(e.m_LiteralDecoder, o, r);
                                var s = 1 << n;
                                return N(e.m_LenDecoder, s), N(e.m_RepLenDecoder, s), e.m_PosStateMask = s - 1, 1;
                            }(e, s, i, a) ? 0 : function (e, r) {return 0 > r ? 0 : (e.m_DictionarySize != r && (e.m_DictionarySize = r, e.m_DictionarySizeCheck = Math.max(e.m_DictionarySize, 1), function (e, r) {null != e._buffer && e._windowSize == r || (e._buffer = t(r)), e._windowSize = r, e._pos = 0, e._streamPos = 0;}(e.m_OutWindow, Math.max(e.m_DictionarySizeCheck, 4096))), 1);}(e, o);
                        }(n = function (e) {
                            e.m_OutWindow = {}, e.m_RangeDecoder = {}, e.m_IsMatchDecoders = t(192), e.m_IsRepDecoders = t(12), e.m_IsRepG0Decoders = t(12), e.m_IsRepG1Decoders = t(12), e.m_IsRepG2Decoders = t(12), e.m_IsRep0LongDecoders = t(192), e.m_PosSlotDecoder = t(4), e.m_PosDecoders = t(114), e.m_PosAlignDecoder = fe({}, 4), e.m_LenDecoder = H({}), e.m_RepLenDecoder = H({}), e.m_LiteralDecoder = {};
                            for (var r = 0; 4 > r; ++r) e.m_PosSlotDecoder[r] = fe({}, 6);
                            return e;
                        }({}), u)) throw Error('corrupted input');
                        for (s = 0; 64 > s; s += 8) {
                            if (-1 == (i = h(r))) throw Error('truncated input');
                            1 == (i = i.toString(16)).length && (i = '0' + i), _ = i + '' + _;
                        }
                        e.length_0 = /^0+$|^f+$/i.test(_) || (a = parseInt(_, 16)) > 4294967295 ? xe : c(a), e.chunker = function (e, r, t, o) {
                            return e.m_RangeDecoder.Stream = r, F(e.m_OutWindow), e.m_OutWindow._stream = t, function (e) {
                                e.m_OutWindow._streamPos = 0, e.m_OutWindow._pos = 0, Se(e.m_IsMatchDecoders), Se(e.m_IsRep0LongDecoders), Se(e.m_IsRepDecoders), Se(e.m_IsRepG0Decoders), Se(e.m_IsRepG1Decoders), Se(e.m_IsRepG2Decoders), Se(e.m_PosDecoders), function (e) {
                                    var r, t;
                                    for (t = 1 << e.m_NumPrevBits + e.m_NumPosBits, r = 0; t > r; ++r) Se(e.m_Coders[r].m_Decoders);
                                }(e.m_LiteralDecoder);
                                for (var r = 0; 4 > r; ++r) Se(e.m_PosSlotDecoder[r].Models);
                                G(e.m_LenDecoder), G(e.m_RepLenDecoder), Se(e.m_PosAlignDecoder.Models), function (e) {
                                    e.Code = 0, e.Range = -1;
                                    for (var r = 0; 5 > r; ++r) e.Code = e.Code << 8 | h(e.Stream);
                                }(e.m_RangeDecoder);
                            }(e), e.state = 0, e.rep0 = 0, e.rep1 = 0, e.rep2 = 0, e.rep3 = 0, e.outSize = o, e.nowPos64 = Oe, e.prevByte = 0, function (e, r) {return e.decoder = r, e.encoder = null, e.alive = 1, e;}({}, e);
                        }(n, r, o, e.length_0);
                    }(e, p({}, r), e.output), e;
                }

                function y(e, r) {return e._bufferBase[e._bufferOffset + e._pos + r];}

                function b(e, r, t, o) {
                    var n, s;
                    for (e._streamEndWasReached && e._pos + r + o > e._streamPos && (o = e._streamPos - (e._pos + r)), ++t, s = e._bufferOffset + e._pos + r, n = 0; o > n && e._bufferBase[s + n] == e._bufferBase[s + n - t]; ++n) ;
                    return n;
                }

                function R(e) {return e._streamPos - e._pos;}

                function D(e) {
                    var r, t;
                    if (!e._streamEndWasReached) for (; ;) {
                        if (!(t = -e._bufferOffset + e._blockSize - e._streamPos)) return;
                        if (-1 == (r = l(e._stream, e._bufferBase, e._bufferOffset + e._streamPos, t))) return e._posLimit = e._streamPos, e._bufferOffset + e._posLimit > e._pointerToLastSafePosition && (e._posLimit = e._pointerToLastSafePosition - e._bufferOffset), void (e._streamEndWasReached = 1);
                        e._streamPos += r, e._pos + e._keepSizeAfter > e._streamPos || (e._posLimit = e._streamPos - e._keepSizeAfter);
                    }
                }

                function M(e, r) {e._bufferOffset += r, e._posLimit -= r, e._pos -= r, e._streamPos -= r;}

                function C(e) {
                    var r;
                    ++e._cyclicBufferPos < e._cyclicBufferSize || (e._cyclicBufferPos = 0), function (e) {
                        ++e._pos, e._pos > e._posLimit && (e._bufferOffset + e._pos > e._pointerToLastSafePosition && function (e) {
                            var r, t, o;
                            for ((o = e._bufferOffset + e._pos - e._keepSizeBefore) > 0 && --o, t = e._bufferOffset + e._streamPos - o, r = 0; t > r; ++r) e._bufferBase[r] = e._bufferBase[o + r];
                            e._bufferOffset -= o;
                        }(e), D(e));
                    }(e), 1073741823 == e._pos && (L(e._son, 2 * e._cyclicBufferSize, r = e._pos - e._cyclicBufferSize), L(e._hash, e._hashSizeSum, r), M(e, r));
                }

                function L(e, r, t) {
                    var o, n;
                    for (o = 0; r > o; ++o) (n = e[o] || 0) > t ? n -= t : n = 0, e[o] = n;
                }

                function E(e) {
                    var r = e._pos - e._streamPos;
                    r && (g(e._stream, e._buffer, e._streamPos, r), e._windowSize > e._pos || (e._pos = 0), e._streamPos = e._pos);
                }

                function z(e, r) {
                    var t = e._pos - r - 1;
                    return 0 > t && (t += e._windowSize), e._buffer[t];
                }

                function F(e) {E(e), e._stream = null;}

                function x(e) {return 4 > (e -= 2) ? e : 3;}

                function I(e) {return 4 > e ? 0 : 10 > e ? e - 3 : e - 6;}

                function O(e) {
                    if (!e.alive) throw Error('bad state');
                    return e.encoder ? function (e) {
                        (function (e, r, t, n) {
                            var i, u, f, m, p, h, l, P, v, B, g, S, w, k, b;
                            if (r[0] = Oe, t[0] = Oe, n[0] = 1, e._inStream && (e._matchFinder._stream = e._inStream, function (e) {e._bufferOffset = 0, e._pos = 0, e._streamPos = 0, e._streamEndWasReached = 0, D(e), e._cyclicBufferPos = 0, M(e, -1);}(e._matchFinder), e._needReleaseMFStream = 1, e._inStream = null), !e._finished) {
                                if (e._finished = 1, k = e.nowPos64, a(e.nowPos64, Oe)) {
                                    if (!R(e._matchFinder)) return void Y(e, _(e.nowPos64));
                                    K(e), w = _(e.nowPos64) & e._posStateMask, we(e._rangeEncoder, e._isMatch, (e._state << 4) + w, 0), e._state = I(e._state), f = y(e._matchFinder, -e._additionalOffset), ie(se(e._literalEncoder, _(e.nowPos64), e._previousByte), e._rangeEncoder, f), e._previousByte = f, --e._additionalOffset, e.nowPos64 = o(e.nowPos64, Ne);
                                }
                                if (R(e._matchFinder)) for (; ;) {
                                    if (l = U(e, _(e.nowPos64)), B = e.backRes, w = _(e.nowPos64) & e._posStateMask, u = (e._state << 4) + w, 1 == l && -1 == B) we(e._rangeEncoder, e._isMatch, u, 0), f = y(e._matchFinder, -e._additionalOffset), b = se(e._literalEncoder, _(e.nowPos64), e._previousByte), 7 > e._state ? ie(b, e._rangeEncoder, f) : (v = y(e._matchFinder, -e._repDistances[0] - 1 - e._additionalOffset), ae(b, e._rangeEncoder, v, f)), e._previousByte = f, e._state = I(e._state); else {
                                        if (we(e._rangeEncoder, e._isMatch, u, 1), 4 > B) {
                                            if (we(e._rangeEncoder, e._isRep, e._state, 1), B ? (we(e._rangeEncoder, e._isRepG0, e._state, 1), 1 == B ? we(e._rangeEncoder, e._isRepG1, e._state, 0) : (we(e._rangeEncoder, e._isRepG1, e._state, 1), we(e._rangeEncoder, e._isRepG2, e._state, B - 2))) : (we(e._rangeEncoder, e._isRepG0, e._state, 0), we(e._rangeEncoder, e._isRep0Long, u, 1 == l ? 0 : 1)), 1 == l ? e._state = 7 > e._state ? 9 : 11 : (re(e._repMatchLenEncoder, e._rangeEncoder, l - 2, w), e._state = 7 > e._state ? 8 : 11), m = e._repDistances[B], 0 != B) {
                                                for (h = B; h >= 1; --h) e._repDistances[h] = e._repDistances[h - 1];
                                                e._repDistances[0] = m;
                                            }
                                        } else {
                                            for (we(e._rangeEncoder, e._isRep, e._state, 0), e._state = 7 > e._state ? 7 : 10, re(e._lenEncoder, e._rangeEncoder, l - 2, w), S = X(B -= 4), P = x(l), pe(e._posSlotEncoder[P], e._rangeEncoder, S), 4 > S || (g = B - (i = (2 | 1 & S) << (p = (S >> 1) - 1)), 14 > S ? ve(e._posEncoders, i - S - 1, e._rangeEncoder, p, g) : (ke(e._rangeEncoder, g >> 4, p - 4), le(e._posAlignEncoder, e._rangeEncoder, 15 & g), ++e._alignPriceCount)), m = B, h = 3; h >= 1; --h) e._repDistances[h] = e._repDistances[h - 1];
                                            e._repDistances[0] = m, ++e._matchPriceCount;
                                        }
                                        e._previousByte = y(e._matchFinder, l - 1 - e._additionalOffset);
                                    }
                                    if (e._additionalOffset -= l, e.nowPos64 = o(e.nowPos64, c(l)), !e._additionalOffset) {
                                        if (128 > e._matchPriceCount || V(e), 16 > e._alignPriceCount || j(e), r[0] = e.nowPos64, t[0] = ye(e._rangeEncoder), !R(e._matchFinder)) return void Y(e, _(e.nowPos64));
                                        if (s(d(e.nowPos64, k), [4096, 0]) >= 0) return e._finished = 0, void (n[0] = 0);
                                    }
                                } else Y(e, _(e.nowPos64));
                            }
                        })(e.encoder, e.encoder.processedInSize, e.encoder.processedOutSize, e.encoder.finished), e.inBytesProcessed = e.encoder.processedInSize[0], e.encoder.finished[0] && (function (e) {Q(e), e._rangeEncoder.Stream = null;}(e.encoder), e.alive = 0);
                    }(e) : function (e) {
                        var r = function (e) {
                            var r, t, n, i, a, u;
                            if (u = _(e.nowPos64) & e.m_PosStateMask, ge(e.m_RangeDecoder, e.m_IsMatchDecoders, (e.state << 4) + u)) {
                                if (ge(e.m_RangeDecoder, e.m_IsRepDecoders, e.state)) n = 0, ge(e.m_RangeDecoder, e.m_IsRepG0Decoders, e.state) ? (ge(e.m_RangeDecoder, e.m_IsRepG1Decoders, e.state) ? (ge(e.m_RangeDecoder, e.m_IsRepG2Decoders, e.state) ? (t = e.rep3, e.rep3 = e.rep2) : t = e.rep2, e.rep2 = e.rep1) : t = e.rep1, e.rep1 = e.rep0, e.rep0 = t) : ge(e.m_RangeDecoder, e.m_IsRep0LongDecoders, (e.state << 4) + u) || (e.state = 7 > e.state ? 9 : 11, n = 1), n || (n = A(e.m_RepLenDecoder, e.m_RangeDecoder, u) + 2, e.state = 7 > e.state ? 8 : 11); else if (e.rep3 = e.rep2, e.rep2 = e.rep1, e.rep1 = e.rep0, n = 2 + A(e.m_LenDecoder, e.m_RangeDecoder, u), e.state = 7 > e.state ? 7 : 10, 4 > (a = me(e.m_PosSlotDecoder[x(n)], e.m_RangeDecoder))) e.rep0 = a; else if (e.rep0 = (2 | 1 & a) << (i = (a >> 1) - 1), 14 > a) e.rep0 += function (e, r, t, o) {
                                    var n, s, i = 1, a = 0;
                                    for (s = 0; o > s; ++s) n = ge(t, e, r + i), i <<= 1, i += n, a |= n << s;
                                    return a;
                                }(e.m_PosDecoders, e.rep0 - a - 1, e.m_RangeDecoder, i); else if (e.rep0 += function (e, r) {
                                    var t, o, n = 0;
                                    for (t = r; 0 != t; --t) e.Range >>>= 1, e.Code -= e.Range & (o = e.Code - e.Range >>> 31) - 1, n = n << 1 | 1 - o, -16777216 & e.Range || (e.Code = e.Code << 8 | h(e.Stream), e.Range <<= 8);
                                    return n;
                                }(e.m_RangeDecoder, i - 4) << 4, e.rep0 += function (e, r) {
                                    var t, o, n = 1, s = 0;
                                    for (o = 0; e.NumBitLevels > o; ++o) t = ge(r, e.Models, n), n <<= 1, n += t, s |= t << o;
                                    return s;
                                }(e.m_PosAlignDecoder, e.m_RangeDecoder), 0 > e.rep0) return -1 == e.rep0 ? 1 : -1;
                                if (s(c(e.rep0), e.nowPos64) >= 0 || e.rep0 >= e.m_DictionarySizeCheck) return -1;
                                !function (e, r, t) {
                                    var o = e._pos - r - 1;
                                    for (0 > o && (o += e._windowSize); 0 != t; --t) e._windowSize > o || (o = 0), e._buffer[e._pos++] = e._buffer[o++], e._windowSize > e._pos || E(e);
                                }(e.m_OutWindow, e.rep0, n), e.nowPos64 = o(e.nowPos64, c(n)), e.prevByte = z(e.m_OutWindow, 0);
                            } else r = function (e, r, t) {return e.m_Coders[((r & e.m_PosMask) << e.m_NumPrevBits) + ((255 & t) >>> 8 - e.m_NumPrevBits)];}(e.m_LiteralDecoder, _(e.nowPos64), e.prevByte), e.prevByte = 7 > e.state ? function (e, r) {
                                var t = 1;
                                do {
                                    t = t << 1 | ge(r, e.m_Decoders, t);
                                } while (256 > t);
                                return t << 24 >> 24;
                            }(r, e.m_RangeDecoder) : function (e, r, t) {
                                var o, n, s = 1;
                                do {
                                    if (n = t >> 7 & 1, t <<= 1, s = s << 1 | (o = ge(r, e.m_Decoders, (1 + n << 8) + s)), n != o) {
                                        for (; 256 > s;) s = s << 1 | ge(r, e.m_Decoders, s);
                                        break;
                                    }
                                } while (256 > s);
                                return s << 24 >> 24;
                            }(r, e.m_RangeDecoder, z(e.m_OutWindow, e.rep0)), function (e, r) {e._buffer[e._pos++] = r, e._windowSize > e._pos || E(e);}(e.m_OutWindow, e.prevByte), e.state = I(e.state), e.nowPos64 = o(e.nowPos64, Ne);
                            return 0;
                        }(e.decoder);
                        if (-1 == r) throw Error('corrupted input');
                        e.inBytesProcessed = xe, e.outBytesProcessed = e.decoder.nowPos64, (r || s(e.decoder.outSize, Oe) >= 0 && s(e.decoder.nowPos64, e.decoder.outSize) >= 0) && (E(e.decoder.m_OutWindow), F(e.decoder.m_OutWindow), e.decoder.m_RangeDecoder.Stream = null, e.alive = 0);
                    }(e), e.alive;
                }

                function N(e, r) {for (; r > e.m_NumPosStates; ++e.m_NumPosStates) e.m_LowCoder[e.m_NumPosStates] = fe({}, 3), e.m_MidCoder[e.m_NumPosStates] = fe({}, 3);}

                function A(e, r, t) {
                    if (!ge(r, e.m_Choice, 0)) return me(e.m_LowCoder[t], r);
                    var o = 8;
                    return ge(r, e.m_Choice, 1) ? o += 8 + me(e.m_HighCoder, r) : o += me(e.m_MidCoder[t], r), o;
                }

                function H(e) {return e.m_Choice = t(2), e.m_LowCoder = t(16), e.m_MidCoder = t(16), e.m_HighCoder = fe({}, 8), e.m_NumPosStates = 0, e;}

                function G(e) {
                    Se(e.m_Choice);
                    for (var r = 0; e.m_NumPosStates > r; ++r) Se(e.m_LowCoder[r].Models), Se(e.m_MidCoder[r].Models);
                    Se(e.m_HighCoder.Models);
                }

                function T(e) {return e.m_Decoders = t(768), e;}

                function W(e, r) {
                    var t, o, n, s;
                    e._optimumEndIndex = r, n = e._optimum[r].PosPrev, o = e._optimum[r].BackPrev;
                    do {
                        e._optimum[r].Prev1IsChar && (ue(e._optimum[n]), e._optimum[n].PosPrev = n - 1, e._optimum[r].Prev2 && (e._optimum[n - 1].Prev1IsChar = 0, e._optimum[n - 1].PosPrev = e._optimum[r].PosPrev2, e._optimum[n - 1].BackPrev = e._optimum[r].BackPrev2)), t = o, o = e._optimum[s = n].BackPrev, n = e._optimum[s].PosPrev, e._optimum[s].BackPrev = t, e._optimum[s].PosPrev = r, r = s;
                    } while (r > 0);
                    return e.backRes = e._optimum[0].BackPrev, e._optimumCurrentIndex = e._optimum[0].PosPrev, e._optimumCurrentIndex;
                }

                function j(e) {
                    for (var r = 0; 16 > r; ++r) e._alignPrices[r] = Pe(e._posAlignEncoder, r);
                    e._alignPriceCount = 0;
                }

                function V(e) {
                    var r, t, o, n, s, i, a, c;
                    for (n = 4; 128 > n; ++n) i = X(n), e.tempPrices[n] = Be(e._posEncoders, (r = (2 | 1 & i) << (o = (i >> 1) - 1)) - i - 1, o, n - r);
                    for (s = 0; 4 > s; ++s) {
                        for (t = e._posSlotEncoder[s], a = s << 6, i = 0; e._distTableSize > i; ++i) e._posSlotPrices[a + i] = he(t, i);
                        for (i = 14; e._distTableSize > i; ++i) e._posSlotPrices[a + i] += (i >> 1) - 1 - 4 << 6;
                        for (c = 128 * s, n = 0; 4 > n; ++n) e._distancesPrices[c + n] = e._posSlotPrices[a + n];
                        for (; 128 > n; ++n) e._distancesPrices[c + n] = e._posSlotPrices[a + X(n)] + e.tempPrices[n];
                    }
                    e._matchPriceCount = 0;
                }

                function Y(e, r) {
                    Q(e), function (e, r) {
                        if (e._writeEndMark) {
                            we(e._rangeEncoder, e._isMatch, (e._state << 4) + r, 1), we(e._rangeEncoder, e._isRep, e._state, 0), e._state = 7 > e._state ? 7 : 10, re(e._lenEncoder, e._rangeEncoder, 0, r);
                            var t = x(2);
                            pe(e._posSlotEncoder[t], e._rangeEncoder, 63), ke(e._rangeEncoder, 67108863, 26), le(e._posAlignEncoder, e._rangeEncoder, 15);
                        }
                    }(e, r & e._posStateMask);
                    for (var t = 0; 5 > t; ++t) be(e._rangeEncoder);
                }

                function U(e, r) {
                    var t, o, n, s, i, a, c, _, u, f, m, d, p, h, l, P, v, B, g, S, w, k, D, M, C, L, E, z, F, x, O, N, A, H, G, T, j, V, Y, U, Q, X, Z;
                    if (e._optimumEndIndex != e._optimumCurrentIndex) return p = e._optimum[e._optimumCurrentIndex].PosPrev - e._optimumCurrentIndex, e.backRes = e._optimum[e._optimumCurrentIndex].BackPrev, e._optimumCurrentIndex = e._optimum[e._optimumCurrentIndex].PosPrev, p;
                    if (e._optimumCurrentIndex = e._optimumEndIndex = 0, e._longestMatchWasFound ? (d = e._longestMatchLength, e._longestMatchWasFound = 0) : d = K(e), L = e._numDistancePairs, 2 > (M = R(e._matchFinder) + 1)) return e.backRes = -1, 1;
                    for (M > 273 && (M = 273), Y = 0, u = 0; 4 > u; ++u) e.reps[u] = e._repDistances[u], e.repLens[u] = b(e._matchFinder, -1, e.reps[u], 273), e.repLens[u] > e.repLens[Y] && (Y = u);
                    if (e.repLens[Y] >= e._numFastBytes) return e.backRes = Y, J(e, (p = e.repLens[Y]) - 1), p;
                    if (d >= e._numFastBytes) return e.backRes = e._matchDistances[L - 1] + 4, J(e, d - 1), d;
                    if (c = y(e._matchFinder, -1), v = y(e._matchFinder, -e._repDistances[0] - 1 - 1), 2 > d && c != v && 2 > e.repLens[Y]) return e.backRes = -1, 1;
                    if (e._optimum[0].State = e._state, e._optimum[1].Price = Ge[e._isMatch[(e._state << 4) + (A = r & e._posStateMask)] >>> 2] + _e(se(e._literalEncoder, r, e._previousByte), e._state >= 7, v, c), ue(e._optimum[1]), V = (B = Ge[2048 - e._isMatch[(e._state << 4) + A] >>> 2]) + Ge[2048 - e._isRep[e._state] >>> 2], v == c && (U = V + function (e, r, t) {return Ge[e._isRepG0[r] >>> 2] + Ge[e._isRep0Long[(r << 4) + t] >>> 2];}(e, e._state, A), e._optimum[1].Price > U && (e._optimum[1].Price = U, function (e) {e.BackPrev = 0, e.Prev1IsChar = 0;}(e._optimum[1]))), 2 > (m = e.repLens[Y] > d ? e.repLens[Y] : d)) return e.backRes = e._optimum[1].BackPrev, 1;
                    e._optimum[1].PosPrev = 0, e._optimum[0].Backs0 = e.reps[0], e._optimum[0].Backs1 = e.reps[1], e._optimum[0].Backs2 = e.reps[2], e._optimum[0].Backs3 = e.reps[3], f = m;
                    do {
                        e._optimum[f--].Price = 268435455;
                    } while (f >= 2);
                    for (u = 0; 4 > u; ++u) if ((j = e.repLens[u]) >= 2) {
                        G = V + q(e, u, e._state, A);
                        do {
                            s = G + oe(e._repMatchLenEncoder, j - 2, A), (x = e._optimum[j]).Price > s && (x.Price = s, x.PosPrev = 0, x.BackPrev = u, x.Prev1IsChar = 0);
                        } while (--j >= 2);
                    }
                    if (D = B + Ge[e._isRep[e._state] >>> 2], d >= (f = 2 > e.repLens[0] ? 2 : e.repLens[0] + 1)) {
                        for (E = 0; f > e._matchDistances[E];) E += 2;
                        for (; s = D + $(e, _ = e._matchDistances[E + 1], f, A), (x = e._optimum[f]).Price > s && (x.Price = s, x.PosPrev = 0, x.BackPrev = _ + 4, x.Prev1IsChar = 0), f != e._matchDistances[E] || (E += 2) != L; ++f) ;
                    }
                    for (t = 0; ;) {
                        if (++t == m) return W(e, t);
                        if (g = K(e), L = e._numDistancePairs, g >= e._numFastBytes) return e._longestMatchLength = g, e._longestMatchWasFound = 1, W(e, t);
                        if (++r, N = e._optimum[t].PosPrev, e._optimum[t].Prev1IsChar ? (--N, e._optimum[t].Prev2 ? (X = e._optimum[e._optimum[t].PosPrev2].State, X = 4 > e._optimum[t].BackPrev2 ? 7 > X ? 8 : 11 : 7 > X ? 7 : 10) : X = e._optimum[N].State, X = I(X)) : X = e._optimum[N].State, N == t - 1 ? X = e._optimum[t].BackPrev ? I(X) : 7 > X ? 9 : 11 : (e._optimum[t].Prev1IsChar && e._optimum[t].Prev2 ? (N = e._optimum[t].PosPrev2, O = e._optimum[t].BackPrev2, X = 7 > X ? 8 : 11) : X = 4 > (O = e._optimum[t].BackPrev) ? 7 > X ? 8 : 11 : 7 > X ? 7 : 10, F = e._optimum[N], 4 > O ? O ? 1 == O ? (e.reps[0] = F.Backs1, e.reps[1] = F.Backs0, e.reps[2] = F.Backs2, e.reps[3] = F.Backs3) : 2 == O ? (e.reps[0] = F.Backs2, e.reps[1] = F.Backs0, e.reps[2] = F.Backs1, e.reps[3] = F.Backs3) : (e.reps[0] = F.Backs3, e.reps[1] = F.Backs0, e.reps[2] = F.Backs1, e.reps[3] = F.Backs2) : (e.reps[0] = F.Backs0, e.reps[1] = F.Backs1, e.reps[2] = F.Backs2, e.reps[3] = F.Backs3) : (e.reps[0] = O - 4, e.reps[1] = F.Backs0, e.reps[2] = F.Backs1, e.reps[3] = F.Backs2)), e._optimum[t].State = X, e._optimum[t].Backs0 = e.reps[0], e._optimum[t].Backs1 = e.reps[1], e._optimum[t].Backs2 = e.reps[2], e._optimum[t].Backs3 = e.reps[3], a = e._optimum[t].Price, c = y(e._matchFinder, -1), v = y(e._matchFinder, -e.reps[0] - 1 - 1), o = a + Ge[e._isMatch[(X << 4) + (A = r & e._posStateMask)] >>> 2] + _e(se(e._literalEncoder, r, y(e._matchFinder, -2)), X >= 7, v, c), S = 0, (w = e._optimum[t + 1]).Price > o && (w.Price = o, w.PosPrev = t, w.BackPrev = -1, w.Prev1IsChar = 0, S = 1), V = (B = a + Ge[2048 - e._isMatch[(X << 4) + A] >>> 2]) + Ge[2048 - e._isRep[X] >>> 2], v != c || t > w.PosPrev && !w.BackPrev || (U = V + (Ge[e._isRepG0[X] >>> 2] + Ge[e._isRep0Long[(X << 4) + A] >>> 2])) > w.Price || (w.Price = U, w.PosPrev = t, w.BackPrev = 0, w.Prev1IsChar = 0, S = 1), (M = C = (C = R(e._matchFinder) + 1) > 4095 - t ? 4095 - t : C) >= 2) {
                            if (M > e._numFastBytes && (M = e._numFastBytes), !S && v != c && (l = b(e._matchFinder, 0, e.reps[0], Math.min(C - 1, e._numFastBytes))) >= 2) {
                                for (Z = I(X), k = o + Ge[2048 - e._isMatch[(Z << 4) + (H = r + 1 & e._posStateMask)] >>> 2] + Ge[2048 - e._isRep[Z] >>> 2], z = t + 1 + l; z > m;) e._optimum[++m].Price = 268435455;
                                s = k + (oe(e._repMatchLenEncoder, l - 2, H) + q(e, 0, Z, H)), (x = e._optimum[z]).Price > s && (x.Price = s, x.PosPrev = t + 1, x.BackPrev = 0, x.Prev1IsChar = 1, x.Prev2 = 0);
                            }
                            for (Q = 2, T = 0; 4 > T; ++T) if ((h = b(e._matchFinder, -1, e.reps[T], M)) >= 2) {
                                P = h;
                                do {
                                    for (; t + h > m;) e._optimum[++m].Price = 268435455;
                                    s = V + (oe(e._repMatchLenEncoder, h - 2, A) + q(e, T, X, A)), (x = e._optimum[t + h]).Price > s && (x.Price = s, x.PosPrev = t, x.BackPrev = T, x.Prev1IsChar = 0);
                                } while (--h >= 2);
                                if (h = P, T || (Q = h + 1), C > h && (l = b(e._matchFinder, h, e.reps[T], Math.min(C - 1 - h, e._numFastBytes))) >= 2) {
                                    for (Z = 7 > X ? 8 : 11, H = r + h & e._posStateMask, n = V + (oe(e._repMatchLenEncoder, h - 2, A) + q(e, T, X, A)) + Ge[e._isMatch[(Z << 4) + H] >>> 2] + _e(se(e._literalEncoder, r + h, y(e._matchFinder, h - 1 - 1)), 1, y(e._matchFinder, h - 1 - (e.reps[T] + 1)), y(e._matchFinder, h - 1)), Z = I(Z), k = n + Ge[2048 - e._isMatch[(Z << 4) + (H = r + h + 1 & e._posStateMask)] >>> 2] + Ge[2048 - e._isRep[Z] >>> 2], z = h + 1 + l; t + z > m;) e._optimum[++m].Price = 268435455;
                                    s = k + (oe(e._repMatchLenEncoder, l - 2, H) + q(e, 0, Z, H)), (x = e._optimum[t + z]).Price > s && (x.Price = s, x.PosPrev = t + h + 1, x.BackPrev = 0, x.Prev1IsChar = 1, x.Prev2 = 1, x.PosPrev2 = t, x.BackPrev2 = T);
                                }
                            }
                            if (g > M) {
                                for (g = M, L = 0; g > e._matchDistances[L]; L += 2) ;
                                e._matchDistances[L] = g, L += 2;
                            }
                            if (g >= Q) {
                                for (D = B + Ge[e._isRep[X] >>> 2]; t + g > m;) e._optimum[++m].Price = 268435455;
                                for (E = 0; Q > e._matchDistances[E];) E += 2;
                                for (h = Q; ; ++h) if (s = D + $(e, i = e._matchDistances[E + 1], h, A), (x = e._optimum[t + h]).Price > s && (x.Price = s, x.PosPrev = t, x.BackPrev = i + 4, x.Prev1IsChar = 0), h == e._matchDistances[E]) {
                                    if (C > h && (l = b(e._matchFinder, h, i, Math.min(C - 1 - h, e._numFastBytes))) >= 2) {
                                        for (n = s + Ge[e._isMatch[((Z = 7 > X ? 7 : 10) << 4) + (H = r + h & e._posStateMask)] >>> 2] + _e(se(e._literalEncoder, r + h, y(e._matchFinder, h - 1 - 1)), 1, y(e._matchFinder, h - (i + 1) - 1), y(e._matchFinder, h - 1)), Z = I(Z), k = n + Ge[2048 - e._isMatch[(Z << 4) + (H = r + h + 1 & e._posStateMask)] >>> 2] + Ge[2048 - e._isRep[Z] >>> 2], z = h + 1 + l; t + z > m;) e._optimum[++m].Price = 268435455;
                                        s = k + (oe(e._repMatchLenEncoder, l - 2, H) + q(e, 0, Z, H)), (x = e._optimum[t + z]).Price > s && (x.Price = s, x.PosPrev = t + h + 1, x.BackPrev = 0, x.Prev1IsChar = 1, x.Prev2 = 1, x.PosPrev2 = t, x.BackPrev2 = i + 4);
                                    }
                                    if ((E += 2) == L) break;
                                }
                            }
                        }
                    }
                }

                function $(e, r, t, o) {
                    var n = x(t);
                    return (128 > r ? e._distancesPrices[128 * n + r] : e._posSlotPrices[(n << 6) + function (e) {return 131072 > e ? He[e >> 6] + 12 : 134217728 > e ? He[e >> 16] + 32 : He[e >> 26] + 52;}(r)] + e._alignPrices[15 & r]) + oe(e._lenEncoder, t - 2, o);
                }

                function q(e, r, t, o) {
                    var n;
                    return r ? (n = Ge[2048 - e._isRepG0[t] >>> 2], 1 == r ? n += Ge[e._isRepG1[t] >>> 2] : (n += Ge[2048 - e._isRepG1[t] >>> 2], n += Re(e._isRepG2[t], r - 2))) : (n = Ge[e._isRepG0[t] >>> 2], n += Ge[2048 - e._isRep0Long[(t << 4) + o] >>> 2]), n;
                }

                function J(e, r) {
                    r > 0 && (function (e, r) {
                        var t, o, n, s, i, a, c, _, u, f, m, d, p, h, l;
                        do {
                            if (e._pos + e._matchMaxLen > e._streamPos) {
                                if (e.kMinMatchCheck > (f = e._streamPos - e._pos)) {
                                    C(e);
                                    continue;
                                }
                            } else f = e._matchMaxLen;
                            for (m = e._pos > e._cyclicBufferSize ? e._pos - e._cyclicBufferSize : 0, o = e._bufferOffset + e._pos, e.HASH_ARRAY ? (e._hash[1023 & (l = Ae[255 & e._bufferBase[o]] ^ 255 & e._bufferBase[o + 1])] = e._pos, e._hash[1024 + (65535 & (l ^= (255 & e._bufferBase[o + 2]) << 8))] = e._pos, a = (l ^ Ae[255 & e._bufferBase[o + 3]] << 5) & e._hashMask) : a = 255 & e._bufferBase[o] ^ (255 & e._bufferBase[o + 1]) << 8, n = e._hash[e.kFixHashSize + a], e._hash[e.kFixHashSize + a] = e._pos, p = 1 + (e._cyclicBufferPos << 1), h = e._cyclicBufferPos << 1, _ = u = e.kNumHashDirectBytes, t = e._cutValue; ;) {
                                if (m >= n || 0 == t--) {
                                    e._son[p] = e._son[h] = 0;
                                    break;
                                }
                                if (s = ((i = e._pos - n) > e._cyclicBufferPos ? e._cyclicBufferPos - i + e._cyclicBufferSize : e._cyclicBufferPos - i) << 1, e._bufferBase[(d = e._bufferOffset + n) + (c = u > _ ? _ : u)] == e._bufferBase[o + c]) {
                                    for (; ++c != f && e._bufferBase[d + c] == e._bufferBase[o + c];) ;
                                    if (c == f) {
                                        e._son[h] = e._son[s], e._son[p] = e._son[s + 1];
                                        break;
                                    }
                                }
                                (255 & e._bufferBase[o + c]) > (255 & e._bufferBase[d + c]) ? (e._son[h] = n, n = e._son[h = s + 1], u = c) : (e._son[p] = n, n = e._son[p = s], _ = c);
                            }
                            C(e);
                        } while (0 != --r);
                    }(e._matchFinder, r), e._additionalOffset += r);
                }

                function K(e) {
                    var r = 0;
                    return e._numDistancePairs = function (e, r) {
                        var t, o, n, s, i, a, c, _, u, f, m, d, p, h, l, P, v, B, g, S, w;
                        if (e._pos + e._matchMaxLen > e._streamPos) {
                            if (e.kMinMatchCheck > (h = e._streamPos - e._pos)) return C(e), 0;
                        } else h = e._matchMaxLen;
                        for (v = 0, l = e._pos > e._cyclicBufferSize ? e._pos - e._cyclicBufferSize : 0, o = e._bufferOffset + e._pos, P = 1, _ = 0, u = 0, e.HASH_ARRAY ? (_ = 1023 & (w = Ae[255 & e._bufferBase[o]] ^ 255 & e._bufferBase[o + 1]), u = 65535 & (w ^= (255 & e._bufferBase[o + 2]) << 8), f = (w ^ Ae[255 & e._bufferBase[o + 3]] << 5) & e._hashMask) : f = 255 & e._bufferBase[o] ^ (255 & e._bufferBase[o + 1]) << 8, n = e._hash[e.kFixHashSize + f] || 0, e.HASH_ARRAY && (s = e._hash[_] || 0, i = e._hash[1024 + u] || 0, e._hash[_] = e._pos, e._hash[1024 + u] = e._pos, s > l && e._bufferBase[e._bufferOffset + s] == e._bufferBase[o] && (r[v++] = P = 2, r[v++] = e._pos - s - 1), i > l && e._bufferBase[e._bufferOffset + i] == e._bufferBase[o] && (i == s && (v -= 2), r[v++] = P = 3, r[v++] = e._pos - i - 1, s = i), 0 != v && s == n && (v -= 2, P = 1)), e._hash[e.kFixHashSize + f] = e._pos, g = 1 + (e._cyclicBufferPos << 1), S = e._cyclicBufferPos << 1, d = p = e.kNumHashDirectBytes, 0 != e.kNumHashDirectBytes && n > l && e._bufferBase[e._bufferOffset + n + e.kNumHashDirectBytes] != e._bufferBase[o + e.kNumHashDirectBytes] && (r[v++] = P = e.kNumHashDirectBytes, r[v++] = e._pos - n - 1), t = e._cutValue; ;) {
                            if (l >= n || 0 == t--) {
                                e._son[g] = e._son[S] = 0;
                                break;
                            }
                            if (a = ((c = e._pos - n) > e._cyclicBufferPos ? e._cyclicBufferPos - c + e._cyclicBufferSize : e._cyclicBufferPos - c) << 1, e._bufferBase[(B = e._bufferOffset + n) + (m = p > d ? d : p)] == e._bufferBase[o + m]) {
                                for (; ++m != h && e._bufferBase[B + m] == e._bufferBase[o + m];) ;
                                if (m > P && (r[v++] = P = m, r[v++] = c - 1, m == h)) {
                                    e._son[S] = e._son[a], e._son[g] = e._son[a + 1];
                                    break;
                                }
                            }
                            (255 & e._bufferBase[o + m]) > (255 & e._bufferBase[B + m]) ? (e._son[S] = n, n = e._son[S = a + 1], p = m) : (e._son[g] = n, n = e._son[g = a], d = m);
                        }
                        return C(e), v;
                    }(e._matchFinder, e._matchDistances), e._numDistancePairs > 0 && (r = e._matchDistances[e._numDistancePairs - 2]) == e._numFastBytes && (r += b(e._matchFinder, r - 1, e._matchDistances[e._numDistancePairs - 1], 273 - r)), ++e._additionalOffset, r;
                }

                function Q(e) {e._matchFinder && e._needReleaseMFStream && (e._matchFinder._stream = null, e._needReleaseMFStream = 0);}

                function X(e) {return 2048 > e ? He[e] : 2097152 > e ? He[e >> 10] + 20 : He[e >> 20] + 40;}

                function Z(e, r) {
                    Se(e._choice);
                    for (var t = 0; r > t; ++t) Se(e._lowCoder[t].Models), Se(e._midCoder[t].Models);
                    Se(e._highCoder.Models);
                }

                function ee(e, r, t, o, n) {
                    var s, i, a, c, _;
                    for (s = Ge[e._choice[0] >>> 2], a = (i = Ge[2048 - e._choice[0] >>> 2]) + Ge[e._choice[1] >>> 2], c = i + Ge[2048 - e._choice[1] >>> 2], _ = 0, _ = 0; 8 > _; ++_) {
                        if (_ >= t) return;
                        o[n + _] = s + he(e._lowCoder[r], _);
                    }
                    for (; 16 > _; ++_) {
                        if (_ >= t) return;
                        o[n + _] = a + he(e._midCoder[r], _ - 8);
                    }
                    for (; t > _; ++_) o[n + _] = c + he(e._highCoder, _ - 8 - 8);
                }

                function re(e, r, t, o) {!function (e, r, t, o) {8 > t ? (we(r, e._choice, 0, 0), pe(e._lowCoder[o], r, t)) : (t -= 8, we(r, e._choice, 0, 1), 8 > t ? (we(r, e._choice, 1, 0), pe(e._midCoder[o], r, t)) : (we(r, e._choice, 1, 1), pe(e._highCoder, r, t - 8)));}(e, r, t, o), 0 == --e._counters[o] && (ee(e, o, e._tableSize, e._prices, 272 * o), e._counters[o] = e._tableSize);}

                function te(e) {
                    return function (e) {
                        e._choice = t(2), e._lowCoder = t(16), e._midCoder = t(16), e._highCoder = de({}, 8);
                        for (var r = 0; 16 > r; ++r) e._lowCoder[r] = de({}, 3), e._midCoder[r] = de({}, 3);
                    }(e), e._prices = [], e._counters = [], e;
                }

                function oe(e, r, t) {return e._prices[272 * t + r];}

                function ne(e, r) {for (var t = 0; r > t; ++t) ee(e, t, e._tableSize, e._prices, 272 * t), e._counters[t] = e._tableSize;}

                function se(e, r, t) {return e.m_Coders[((r & e.m_PosMask) << e.m_NumPrevBits) + ((255 & t) >>> 8 - e.m_NumPrevBits)];}

                function ie(e, r, t) {
                    var o, n, s = 1;
                    for (n = 7; n >= 0; --n) we(r, e.m_Encoders, s, o = t >> n & 1), s = s << 1 | o;
                }

                function ae(e, r, t, o) {
                    var n, s, i, a, c = 1, _ = 1;
                    for (s = 7; s >= 0; --s) n = o >> s & 1, a = _, c && (a += 1 + (i = t >> s & 1) << 8, c = i == n), we(r, e.m_Encoders, a, n), _ = _ << 1 | n;
                }

                function ce(e) {return e.m_Encoders = t(768), e;}

                function _e(e, r, t, o) {
                    var n, s, i = 1, a = 7, c = 0;
                    if (r) for (; a >= 0; --a) if (c += Re(e.m_Encoders[(1 + (s = t >> a & 1) << 8) + i], n = o >> a & 1), i = i << 1 | n, s != n) {
                        --a;
                        break;
                    }
                    for (; a >= 0; --a) c += Re(e.m_Encoders[i], n = o >> a & 1), i = i << 1 | n;
                    return c;
                }

                function ue(e) {e.BackPrev = -1, e.Prev1IsChar = 0;}

                function fe(e, r) {return e.NumBitLevels = r, e.Models = t(1 << r), e;}

                function me(e, r) {
                    var t, o = 1;
                    for (t = e.NumBitLevels; 0 != t; --t) o = (o << 1) + ge(r, e.Models, o);
                    return o - (1 << e.NumBitLevels);
                }

                function de(e, r) {return e.NumBitLevels = r, e.Models = t(1 << r), e;}

                function pe(e, r, t) {
                    var o, n, s = 1;
                    for (n = e.NumBitLevels; 0 != n;) --n, we(r, e.Models, s, o = t >>> n & 1), s = s << 1 | o;
                }

                function he(e, r) {
                    var t, o, n = 1, s = 0;
                    for (o = e.NumBitLevels; 0 != o;) --o, s += Re(e.Models[n], t = r >>> o & 1), n = (n << 1) + t;
                    return s;
                }

                function le(e, r, t) {
                    var o, n, s = 1;
                    for (n = 0; e.NumBitLevels > n; ++n) we(r, e.Models, s, o = 1 & t), s = s << 1 | o, t >>= 1;
                }

                function Pe(e, r) {
                    var t, o, n = 1, s = 0;
                    for (o = e.NumBitLevels; 0 != o; --o) t = 1 & r, r >>>= 1, s += Re(e.Models[n], t), n = n << 1 | t;
                    return s;
                }

                function ve(e, r, t, o, n) {
                    var s, i, a = 1;
                    for (i = 0; o > i; ++i) we(t, e, r + a, s = 1 & n), a = a << 1 | s, n >>= 1;
                }

                function Be(e, r, t, o) {
                    var n, s, i = 1, a = 0;
                    for (s = t; 0 != s; --s) n = 1 & o, o >>>= 1, a += Ge[(2047 & (e[r + i] - n ^ -n)) >>> 2], i = i << 1 | n;
                    return a;
                }

                function ge(e, r, t) {
                    var o, n = r[t];
                    return (-2147483648 ^ (o = (e.Range >>> 11) * n)) > (-2147483648 ^ e.Code) ? (e.Range = o, r[t] = n + (2048 - n >>> 5) << 16 >> 16, -16777216 & e.Range || (e.Code = e.Code << 8 | h(e.Stream), e.Range <<= 8), 0) : (e.Range -= o, e.Code -= o, r[t] = n - (n >>> 5) << 16 >> 16, -16777216 & e.Range || (e.Code = e.Code << 8 | h(e.Stream), e.Range <<= 8), 1);
                }

                function Se(e) {for (var r = e.length - 1; r >= 0; --r) e[r] = 1024;}

                function we(e, r, t, s) {
                    var i, a = r[t];
                    i = (e.Range >>> 11) * a, s ? (e.Low = o(e.Low, n(c(i), [4294967295, 0])), e.Range -= i, r[t] = a - (a >>> 5) << 16 >> 16) : (e.Range = i, r[t] = a + (2048 - a >>> 5) << 16 >> 16), -16777216 & e.Range || (e.Range <<= 8, be(e));
                }

                function ke(e, r, t) {for (var n = t - 1; n >= 0; --n) e.Range >>>= 1, 1 == (r >>> n & 1) && (e.Low = o(e.Low, c(e.Range))), -16777216 & e.Range || (e.Range <<= 8, be(e));}

                function ye(e) {return o(o(c(e._cacheSize), e._position), [4, 0]);}

                function be(e) {
                    var r, t, i, a, u = _((i = 32, a = m(t = e.Low, i &= 63), 0 > t[1] && (a = o(a, f([2, 0], 31))), a));
                    if (0 != u || 0 > s(e.Low, [4278190080, 0])) {
                        e._position = o(e._position, c(e._cacheSize)), r = e._cache;
                        do {
                            B(e.Stream, r + u), r = 255;
                        } while (0 != --e._cacheSize);
                        e._cache = _(e.Low) >>> 24;
                    }
                    ++e._cacheSize, e.Low = f(n(e.Low, [16777215, 0]), 8);
                }

                function Re(e, r) {return Ge[(2047 & (e - r ^ -r)) >>> 2];}

                function De(e) {
                    for (var r, t, o, n = 0, s = 0, i = e.length, a = [], c = []; i > n; ++n, ++s) {
                        if (128 & (r = 255 & e[n])) if (192 == (224 & r)) {
                            if (n + 1 >= i) return e;
                            if (128 != (192 & (t = 255 & e[++n]))) return e;
                            c[s] = (31 & r) << 6 | 63 & t;
                        } else {
                            if (224 != (240 & r)) return e;
                            if (n + 2 >= i) return e;
                            if (128 != (192 & (t = 255 & e[++n]))) return e;
                            if (128 != (192 & (o = 255 & e[++n]))) return e;
                            c[s] = (15 & r) << 12 | (63 & t) << 6 | 63 & o;
                        } else {
                            if (!r) return e;
                            c[s] = r;
                        }
                        16383 == s && (a.push(String.fromCharCode.apply(String, c)), s = -1);
                    }
                    return s > 0 && (c.length = s, a.push(String.fromCharCode.apply(String, c))), a.join('');
                }

                function Me(e) {
                    var r, t, o, n = [], s = 0, i = e.length;
                    if ('object' == typeof e) return e;
                    for (function (e, r, t, o, n) {
                        var s;
                        for (s = 0; t > s; ++s) o[n++] = e.charCodeAt(s);
                    }(e, 0, i, n, 0), o = 0; i > o; ++o) 1 > (r = n[o]) || r > 127 ? s += r && (128 > r || r > 2047) ? 3 : 2 : ++s;
                    for (t = [], s = 0, o = 0; i > o; ++o) 1 > (r = n[o]) || r > 127 ? r && (128 > r || r > 2047) ? (t[s++] = (224 | r >> 12 & 15) << 24 >> 24, t[s++] = (128 | r >> 6 & 63) << 24 >> 24, t[s++] = (128 | 63 & r) << 24 >> 24) : (t[s++] = (192 | r >> 6 & 31) << 24 >> 24, t[s++] = (128 | 63 & r) << 24 >> 24) : t[s++] = r << 24 >> 24;
                    return t;
                }

                function Ce(e) {return e[1] + e[0];}

                var Le, Ee = 3, ze = 'function' == typeof setImmediate ? setImmediate : setTimeout, Fe = 4294967296, xe = [4294967295, -Fe], Ie = [0, -0x8000000000000000], Oe = [0, 0], Ne = [1, 0], Ae = function () {
                    var e, r, t, o = [];
                    for (e = 0; 256 > e; ++e) {
                        for (t = e, r = 0; 8 > r; ++r) 0 != (1 & t) ? t = t >>> 1 ^ -306674912 : t >>>= 1;
                        o[e] = t;
                    }
                    return o;
                }(), He    = function () {
                    var e, r, t, o = 2, n = [0, 1];
                    for (t = 2; 22 > t; ++t) for (r = 1 << (t >> 1) - 1, e = 0; r > e; ++e, ++o) n[o] = t << 24 >> 24;
                    return n;
                }(), Ge    = function () {
                    var e, r, t, o = [];
                    for (r = 8; r >= 0; --r) for (e = 1 << 9 - r, t = 1 << 9 - r - 1; e > t; ++t) o[t] = (r << 6) + (e - t << 6 >>> 9 - r - 1);
                    return o;
                }(), Te    = (Le = [{ s : 16, f : 64, m : 0 }, { s : 20, f : 64, m : 0 }, { s : 19, f : 64, m : 1 }, { s : 20, f : 64, m : 1 }, { s : 21, f : 128, m : 1 }, { s : 22, f : 128, m : 1 }, { s : 23, f : 128, m : 1 }, { s : 24, f : 255, m : 1 }, { s : 25, f : 255, m : 1 }], function (e) {return Le[e - 1] || Le[6];});
                return 'undefined' == typeof onmessage || 'undefined' != typeof window && void 0 !== window.document || (onmessage = function (r) {r && r.data && (2 == r.data.action ? e.decompress(r.data.data, r.data.cbn) : 1 == r.data.action && e.compress(r.data.data, r.data.mode, r.data.cbn));}), {
                    compress      : function (e, t, o, n) {
                        var s, i, a = {}, c = void 0 === o && void 0 === n;
                        if ('function' != typeof o && (i = o, o = n = 0), n = n || function (e) {if (void 0 !== i) return r(e, i);}, o = o || function (e, r) {if (void 0 !== i) return postMessage({ action : 1, cbn : i, result : e, error : r });}, c) {
                            for (a.c = w({}, Me(e), Te(t)); O(a.c.chunker);) ;
                            return v(a.c.output);
                        }
                        try {
                            a.c = w({}, Me(e), Te(t)), n(0);
                        } catch (e) {
                            return o(null, e);
                        }
                        ze(function _() {
                            try {
                                for (var e, r = (new Date).getTime(); O(a.c.chunker);) if (s = Ce(a.c.chunker.inBytesProcessed) / Ce(a.c.length_0), (new Date).getTime() - r > 200) return n(s), ze(_, 0), 0;
                                n(1), e = v(a.c.output), ze(o.bind(null, e), 0);
                            } catch (_) {
                                o(null, _);
                            }
                        }, 0);
                    }, decompress : function (e, t, o) {
                        var n, s, i, a, c = {}, _ = void 0 === t && void 0 === o;
                        if ('function' != typeof t && (s = t, t = o = 0), o = o || function (e) {if (void 0 !== s) return r(i ? e : -1, s);}, t = t || function (e, r) {if (void 0 !== s) return postMessage({ action : 2, cbn : s, result : e, error : r });}, _) {
                            for (c.d = k({}, e); O(c.d.chunker);) ;
                            return De(v(c.d.output));
                        }
                        try {
                            c.d = k({}, e), a = Ce(c.d.length_0), i = a > -1, o(0);
                        } catch (e) {
                            return t(null, e);
                        }
                        ze(function u() {
                            try {
                                for (var e, r = 0, s = (new Date).getTime(); O(c.d.chunker);) if (++r % 1e3 == 0 && (new Date).getTime() - s > 200) return i && (n = Ce(c.d.chunker.decoder.nowPos64) / a, o(n)), ze(u, 0), 0;
                                o(1), e = De(v(c.d.output)), ze(t.bind(null, e), 0);
                            } catch (u) {
                                t(null, u);
                            }
                        }, 0);
                    }
                };
            }();
            this.N = e;
        }, 490 : (e, r, t) => {
            const o = t(803);
            e.exports = async (e, r) => o(5e3, new Promise(t => {
                try {
                    chrome.tabs.sendMessage(e, r, e => {t(e);});
                } catch (e) {
                    t(!1);
                }
            }));
        }, 803 : e => {
            e.exports = (e, r) => {
                const t = new Promise(r => setTimeout(() => r(!1), e));
                return Promise.race([r, t]);
            };
        }
    }, t  = {};
    (() => {
        async function r() {await chrome.action.setBadgeBackgroundColor({ color : '#d53030' }), await o();}

        const t = e(278), o = e(424), n = (e(490), e(490), e(959), e(128), e(372)), s = (e(532), e(429));
        chrome.alarms.onAlarm.addListener(async e => {
            switch (e.name) {
                case'sync':
                    await (async () => {
                        const { blocking : e } = await s();
                        return chrome.action.setBadgeText({ text : e && e.length > 0 ? e.length + '' : '' });
                    })(), chrome.alarms.create('sync', { when : Date.now() + 1e4 });
            }
        }), chrome.runtime.onInstalled.addListener(async () => {await r(), chrome.alarms.get('sync', e => {e || chrome.alarms.create('sync', { when : Date.now() + 1e4 });});}), chrome.tabs.onActivated.addListener(o), chrome.tabs.onUpdated.addListener((e, r, t) => {if ('complete' === r.status && n(t)) return o();}), chrome.tabs.onRemoved.addListener(async e => {
            const r = await t('tab');
            if (r && r.id === e) return o();
        }), chrome.storage.onChanged.addListener(async e => {
            if (e.processing) {
                const r = e.processing;
                let t = r.hasOwnProperty('newValue') ? r.newValue : null, o = r.hasOwnProperty('oldValue') ? r.oldValue : null;
                if (!t && o) return;
                if (t && t.hasOwnProperty('data') && t.data.length > 0) return chrome.action.setBadgeText({ text : t.data.length > 0 ? t.data.length + '' : '' });
            }
        }), chrome.runtime.onStartup.addListener(async () => {await r();});
    })();
})();